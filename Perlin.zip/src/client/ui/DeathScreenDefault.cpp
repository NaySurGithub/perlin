#include "client/ui/DeathScreen.hpp"

namespace perlin::ui {
    std::string EmbeddedDeathScreenTemplate() {
        std::string t;
        t += R"PERLINRML(<rml>
<head>
<title>death</title>
<style>
body { position: absolute; left: 0px; top: 0px; width: {{w}}px; height: {{h}}px; margin: 0; padding: 0; background: transparent; }
.t { display: block; position: absolute; font-family: minecraft-shadow; white-space: nowrap; overflow: visible; z-index: 3;
      left: 0px; width: {{w}}px; text-align: center; color: #ffffff; }
#bg { display: block; position: absolute; left: 0px; top: 0px; width: {{w}}px; height: {{h}}px; z-index: 1; decorator: vertical-gradient( rgba(80,0,0,96) rgba(128,48,48,160) ); }
#heading { top: 60px; height: 17px; font-size: 16px; line-height: 17px; }
#cause { top: 85px; height: 9px; font-size: 8px; line-height: 9px; }
.btn { display: block; position: absolute; width: 200px; height: 20px; background-color: #000000; z-index: 5; }
.btn div { display: block; position: absolute; }
.btn .rim { left: 1px; top: 1px; width: 197px; height: 16px; background-color: #aaaaaa; }
.btn .face { left: 2px; top: 2px; width: 196px; height: 15px; background-color: #6f6f6f; }
.btn .shade { left: 1px; top: 17px; width: 198px; height: 2px; background-color: #565656; }
.btn .edge { left: 198px; top: 1px; width: 1px; height: 16px; background-color: #565656; }
.btn .lbl { font-family: minecraft-shadow; left: 0px; top: 6px; width: 200px; height: 9px; font-size: 8px; line-height: 9px; text-align: center; color: #ffffff; }
.btn:hover { background-color: #ffffff; }
.btn:hover .rim { background-color: #afafaf; }
.btn:hover .face { background-color: #757575; }
.btn:hover .shade, .btn:hover .edge { background-color: #5c5c5c; }
.btn.off, .btn.off:hover { background-color: #000000; }
.btn.off .rim, .btn.off .face, .btn.off .shade, .btn.off .edge { background-color: #2c2c2c; }
.btn.off .lbl { color: #a0a0a0; }
</style>
</head>
<body>
  <div id="bg"></div>
  <div id="heading" class="t">{{title}}</div>
  <div id="cause" class="t">{{cause}}</div>
  <div id="respawn" class="btn{{off}}" style="left: {{btn_x}}px; top: {{btn1_y}}px;">
    <div class="rim"></div><div class="face"></div><div class="shade"></div><div class="edge"></div>
    <div class="lbl">{{respawn}}</div>
  </div>
  <div id="title" class="btn{{off}}" style="left: {{btn_x}}px; top: {{btn2_y}}px;">
    <div class="rim"></div><div class="face"></div><div class="shade"></div><div class="edge"></div>
    <div class="lbl">{{title_screen}}</div>
  </div>
</body>
</rml>
)PERLINRML";
        return t;
    }
}
