#pragma once
#include "client/ui/UiLayout.hpp"

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

namespace perlin::ui {
    struct ImageStyle {
        float u = 0, v = 0;
        float uw = -1, vh = -1;
        bool hasNine = false;
        float nine[4] = {0, 0, 0, 0};
        int tiled = 0;
        float tileScale = 1.0f;
        std::string clipDirection;
        float clipRatio = 1.0f;
        float r = 1, g = 1, b = 1, alpha = 1;
        bool keepRatio = false;
    };

    struct TextStyle {
        float scale = 1.0f;
        float r = 1, g = 1, b = 1, a = 1;
        bool shadow = false;
        bool outline = false;
        std::string align = "left";
        float linePadding = 0;
    };

    class RmlWriter {
    public:
        explicit RmlWriter(bool comments) : comments(comments) {}

        void Image(float ax, float ay, float w, float h, int z, const std::string& texture, const ImageStyle& style);
        void Item(float ax, float ay, float w, float h, int z, const std::string& itemKey, float alpha = 1.0f,
                  bool glint = false);
        void Rect(float ax, float ay, float w, float h, int z, float r, float g, float b, float a);
        void Text(float ax, float ay, float w, float h, int z, const std::vector<std::string>& lines, const TextStyle& style);
        void Comment(const std::string& text);
        void Link(float ax, float ay, float w, float h, int z, const std::string& command);

        void BeginBox(float ax, float ay, float w, float h, int z, const std::string& cls, const std::string& id, bool clip, float scroll = 0.0f);
        void EndBox();

        void BeginSection();
        void EndSection(const std::string& name);
        const std::unordered_map<std::string, std::string>& Sections() const { return sections; }

        const std::string& Body() const { return body; }
        size_t Elements() const { return count; }

    private:
        std::string body, saved;
        std::unordered_map<std::string, std::string> sections;
        bool comments;
        size_t count = 0;
        float ox = 0, oy = 0;
        std::vector<std::pair<float, float>> origins;
    };

    using CustomRenderer = std::function<void(const LNode&, RmlWriter&)>;

    class RmlEmitter {
    public:
        void Register(const std::string& name, CustomRenderer renderer) { renderers[name] = std::move(renderer); }
        std::string Emit(const LNode& root, float guiW, float guiH, const std::string& extraRcss, bool comments);
        void SetTemplates(std::string hud, std::string chat) { hudTemplate = std::move(hud); chatTemplate = std::move(chat); }
        const std::vector<std::string>& UnknownRenderers() const { return unknown; }
        void SetScroll(float value) { scroll = value; }
        float ContentHeight() const { return contentHeight; }
        float ViewportHeight() const { return viewportHeight; }

    private:
        void Visit(const LNode& n, RmlWriter& out);
        void EmitImage(const LNode& n, RmlWriter& out);
        void EmitLabel(const LNode& n, RmlWriter& out);
        void VisitButton(const LNode& n, RmlWriter& out);
        void VisitScroll(const LNode& n, RmlWriter& out);
        float scroll = 0, contentHeight = 0, viewportHeight = 0;
        std::string viewportName, contentName;

        std::unordered_map<std::string, CustomRenderer> renderers;
        std::string hudTemplate, chatTemplate;
        std::vector<std::string> unknown;
    };

    std::string EscapeRml(const std::string& text);
    std::string DefaultHudTemplate();
    std::string DefaultChatTemplate();
}
