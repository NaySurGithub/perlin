#pragma once
#include "client/Perlin.hpp"
#include "client/input/TouchControls.hpp"
#include "client/platform/AppPlatform.hpp"

#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <string>

struct SDL_Window;
union SDL_Event;

class AppPlatform_SDL : public AppPlatform {
public:
    explicit AppPlatform_SDL(perlin::LaunchArgs args) : args(std::move(args)) {}

    bool Initialize() override;
    void Run() override;
    void Shutdown() override;
    void PumpFrame() override;

    NativeWindowInfo GetNativeWindowInfo() override;
    void GetFramebufferSize(int& width, int& height) override;
    void SetTitle(const std::string& title) override;
    void ShowSignInCode(const std::string& url, const std::string& code) override;
    bool ConfirmDialog(const std::string& title, const std::string& message) override;
    std::unique_ptr<perlin::RenderContext> CreateRenderContext() override;
    void SetTouchState(const perlin::TouchState& state) override;
    bool TakeTouchLayout(std::map<std::string, perlin::TouchPlace>& out) override;
    void DrawTouchOverlay(perlin::RenderContext& renderer) override;

private:
    void HandleEvent(const SDL_Event& event);
    void SetTouchMode(bool on);
    void PumpGamepad();
    struct SDL_Gamepad* gamepad = nullptr;
    bool padState[64] = {};
    std::chrono::steady_clock::time_point padLast{};
    float padScroll = 0.0f;
    void SetClipboard(const std::string& text) override;
    void OpenUrl(const std::string& url) override;
    bool PickFile(const std::string& kind) override;
    bool TakeSurfaceChanged() override { return surfaceChanged.exchange(false); }
    void SetCursorCaptured(bool captured) override;
    bool cursorCaptured = false;
    bool textActive = false;
    bool keyboardShown = false;
    int keyboardPending = 0;
    bool editMouseDown = false;
    std::atomic<bool> surfaceChanged{false};
    void* lastNativeWindow = nullptr;
    bool surfaceLost = false;
    bool recaptureAfterText = false;
    bool touchMode = false;
    perlin::TouchControls touch;

    SDL_Window* window = nullptr;
    NativeWindowInfo native;
    std::unique_ptr<perlin::Perlin> game;
    std::atomic<int> framebufferWidth{1280};
    std::atomic<int> framebufferHeight{720};
    std::mutex titleMutex;
    std::string pendingTitle;
    bool titleDirty = false;
    perlin::LaunchArgs args;
};
