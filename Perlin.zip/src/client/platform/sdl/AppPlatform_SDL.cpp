#include "client/platform/sdl/AppPlatform_SDL.hpp"
#include "client/renderer/bgfx/RenderContext_bgfx.hpp"
#include "client/input/Keys.hpp"
#include "client/input/KeyMapping.hpp"

#include <SDL3/SDL.h>
#include <bgfx/bgfx.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include "util/Paths.hpp"
#include <cstdlib>
#include <memory>
#include <iostream>
#include <thread>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

namespace {
    int KeyFromScancode(SDL_Scancode sc) {
        namespace K = perlin::Key;
        if (sc >= SDL_SCANCODE_A && sc <= SDL_SCANCODE_Z)
            return 'A' + (sc - SDL_SCANCODE_A);
        if (sc >= SDL_SCANCODE_1 && sc <= SDL_SCANCODE_9)
            return '1' + (sc - SDL_SCANCODE_1);
        if (sc == SDL_SCANCODE_0)
            return '0';
        if (sc >= SDL_SCANCODE_F1 && sc <= SDL_SCANCODE_F12)
            return K::F1 + (sc - SDL_SCANCODE_F1);
        switch (sc) {
        case SDL_SCANCODE_SPACE:
            return K::Space;
        case SDL_SCANCODE_LSHIFT:
        case SDL_SCANCODE_RSHIFT:
            return K::Shift;
        case SDL_SCANCODE_LCTRL:
        case SDL_SCANCODE_RCTRL:
            return K::Control;
        case SDL_SCANCODE_LALT:
        case SDL_SCANCODE_RALT:
            return K::Alt;
        case SDL_SCANCODE_ESCAPE:
        case SDL_SCANCODE_AC_BACK:
            return K::Escape;
        case SDL_SCANCODE_RETURN:
            return K::Enter;
        case SDL_SCANCODE_TAB:
            return K::Tab;
        case SDL_SCANCODE_BACKSPACE:
            return K::Backspace;
        case SDL_SCANCODE_PAGEUP:
            return K::PageUp;
        case SDL_SCANCODE_PAGEDOWN:
            return K::PageDown;
        case SDL_SCANCODE_HOME:
            return K::Home;
        case SDL_SCANCODE_END:
            return K::End;
        case SDL_SCANCODE_DELETE:
            return K::Delete;
        case SDL_SCANCODE_SLASH:
            return K::Slash;
        case SDL_SCANCODE_LEFT:
            return K::Left;
        case SDL_SCANCODE_UP:
            return K::Up;
        case SDL_SCANCODE_RIGHT:
            return K::Right;
        case SDL_SCANCODE_DOWN:
            return K::Down;
        default:
            return 0;
        }
    }

    int ButtonIndex(Uint8 button) {
        switch (button) {
        case SDL_BUTTON_LEFT:
            return 0;
        case SDL_BUTTON_RIGHT:
            return 1;
        case SDL_BUTTON_MIDDLE:
            return 2;
        default:
            return -1;
        }
    }
}

#ifdef __EMSCRIPTEN__
EM_JS(int, perlin_js_confirm, (const char* title, const char* message), {
    return confirm(UTF8ToString(title) + "\n\n" + UTF8ToString(message)) ? 1 : 0;
});
#endif

std::unique_ptr<perlin::RenderContext> AppPlatform_SDL::CreateRenderContext() {
    return std::make_unique<perlin::RenderContext_bgfx>();
}

NativeWindowInfo AppPlatform_SDL::GetNativeWindowInfo() {
    return native;
}

void AppPlatform_SDL::GetFramebufferSize(int& width, int& height) {
    width = framebufferWidth;
    height = framebufferHeight;
}

void AppPlatform_SDL::SetTitle(const std::string& title) {
    std::lock_guard lock(titleMutex);
    pendingTitle = title;
    titleDirty = true;
}

void AppPlatform_SDL::ShowSignInCode(const std::string& url, const std::string& code) {
    struct Job {
        std::string url, code;
    };
    SDL_RunOnMainThread(
        [](void* data) {
            std::unique_ptr<Job> job(static_cast<Job*>(data));
            SDL_SetClipboardText(job->code.c_str());
            SDL_OpenURL(job->url.c_str());
        },
        new Job{url, code}, false);
}

void AppPlatform_SDL::SetClipboard(const std::string& text) {
    SDL_RunOnMainThread(
        [](void* data) {
            std::unique_ptr<std::string> t(static_cast<std::string*>(data));
            SDL_SetClipboardText(t->c_str());
        },
        new std::string(text), false);
}

void AppPlatform_SDL::OpenUrl(const std::string& url) {
    SDL_RunOnMainThread(
        [](void* data) {
            std::unique_ptr<std::string> u(static_cast<std::string*>(data));
            SDL_OpenURL(u->c_str());
        },
        new std::string(url), false);
}

#ifdef SDL_PLATFORM_ANDROID
extern "C" void* perlin_bgfx_android_window;
#endif

bool AppPlatform_SDL::PickFile(const std::string& kind) {
#ifdef SDL_PLATFORM_ANDROID
    struct Request {
        AppPlatform_SDL* self;
        std::string kind;
    };
    SDL_RunOnMainThread(
        [](void* data) {
            std::unique_ptr<Request> request(static_cast<Request*>(data));
            static const SDL_DialogFileFilter kImages[] = {{"PNG image", "png"}};
            const bool image = request->kind == "skin" || request->kind == "cape";
            SDL_PropertiesID props = SDL_CreateProperties();
            if (image) {
                SDL_SetPointerProperty(props, SDL_PROP_FILE_DIALOG_FILTERS_POINTER, const_cast<SDL_DialogFileFilter*>(kImages));
                SDL_SetNumberProperty(props, SDL_PROP_FILE_DIALOG_NFILTERS_NUMBER, 1);
            }
            SDL_SetBooleanProperty(props, SDL_PROP_FILE_DIALOG_MANY_BOOLEAN, false);
            SDL_ShowFileDialogWithProperties(
                SDL_FILEDIALOG_OPENFILE,
                [](void* userdata, const char* const* files, int) {
                    std::unique_ptr<Request> req(static_cast<Request*>(userdata));
                    if (!files)
                        return;
                    for (const char* const* f = files; *f; f++) {
                        size_t size = 0;
                        void* bytes = SDL_LoadFile(*f, &size);
                        if (!bytes)
                            continue;
                        const unsigned char* b = static_cast<const unsigned char*>(bytes);
                        std::string ext = ".png";
                        if (size >= 4 && b[0] == 'P' && b[1] == 'K')
                            ext = ".zip";
                        else if (size >= 4 && b[0] == 0 && b[1] == 'a' && b[2] == 's' && b[3] == 'm')
                            ext = ".wasm";
                        const std::string dir = perlin::paths::DataDir() + "/imports";
                        std::error_code ec;
                        std::filesystem::create_directories(dir, ec);
                        const std::string name = (req->kind == "cape" ? "cape_" : req->kind == "skin" ? "skin_" : "import_") +
                                                 std::to_string(SDL_GetTicks()) + ext;
                        const std::string path = dir + "/" + name;
                        if (FILE* out = std::fopen(path.c_str(), "wb")) {
                            std::fwrite(bytes, 1, size, out);
                            std::fclose(out);
                            req->self->PushDropped(path);
                        }
                        SDL_free(bytes);
                    }
                },
                new Request(*request), props);
            SDL_DestroyProperties(props);
        },
        new Request{this, kind}, false);
    return true;
#else
    (void)kind;
    return false;
#endif
}

bool AppPlatform_SDL::ConfirmDialog(const std::string& title, const std::string& message) {
#ifdef __EMSCRIPTEN__
    return perlin_js_confirm(title.c_str(), message.c_str()) == 1;
#else
    SDL_MessageBoxButtonData buttons[2] = {};
    buttons[0].flags = SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT;
    buttons[0].buttonID = 1;
    buttons[0].text = "Yes";
    buttons[1].flags = SDL_MESSAGEBOX_BUTTON_ESCAPEKEY_DEFAULT;
    buttons[1].buttonID = 0;
    buttons[1].text = "No";
    SDL_MessageBoxData data = {};
    data.flags = SDL_MESSAGEBOX_INFORMATION;
    data.window = window;
    data.title = title.c_str();
    data.message = message.c_str();
    data.numbuttons = 2;
    data.buttons = buttons;
    int pressed = 0;
    if (!SDL_ShowMessageBox(&data, &pressed))
        return false;
    return pressed == 1;
#endif
}

void AppPlatform_SDL::SetTouchState(const perlin::TouchState& state) {
    if (touchMode || state.editing || touch.Editing())
        touch.SetState(state);
}

bool AppPlatform_SDL::TakeTouchLayout(std::map<std::string, perlin::TouchPlace>& out) {
    return touch.TakeEditResult(out);
}

void AppPlatform_SDL::SetTouchMode(bool on) {
    if (on == touchMode)
        return;
    if (game)
        touch.Cancel(game->GetInput());
    touchMode = on;
    if (on) {
        if (cursorCaptured) {
            SDL_SetWindowRelativeMouseMode(window, false);
            cursorCaptured = false;
        }
        if (game)
            game->GetInput().SetCaptured(true);
    } else {
        if (game)
            game->GetInput().SetCaptured(false);
        keyboardShown = false;
        SDL_StopTextInput(window);
    }
}

void AppPlatform_SDL::DrawTouchOverlay(perlin::RenderContext& renderer) {
    if ((!touchMode && !touch.Editing()) || !game)
        return;
    touch.SetViewport(framebufferWidth, framebufferHeight);
    touch.Draw(renderer, touch.Gameplay(game->GetInput()));
}

bool AppPlatform_SDL::Initialize() {
#ifdef __EMSCRIPTEN__
    SDL_SetHint(SDL_HINT_EMSCRIPTEN_ASYNCIFY, "0");
#endif
#ifdef SDL_PLATFORM_ANDROID
    touchMode = true;
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
#endif
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "0");
    if (const char* t = std::getenv("PERLIN_TOUCH"))
        touchMode = touchMode || std::atoi(t) != 0;
    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_GAMEPAD)) {
        std::cout << "[sdl] SDL_Init failed: " << SDL_GetError() << std::endl;
        return false;
    }

    SDL_PropertiesID props = SDL_CreateProperties();
    SDL_SetStringProperty(props, SDL_PROP_WINDOW_CREATE_TITLE_STRING, "Perlin");
    SDL_SetNumberProperty(props, SDL_PROP_WINDOW_CREATE_WIDTH_NUMBER, 1280);
    SDL_SetNumberProperty(props, SDL_PROP_WINDOW_CREATE_HEIGHT_NUMBER, 720);
    SDL_SetBooleanProperty(props, SDL_PROP_WINDOW_CREATE_RESIZABLE_BOOLEAN, true);
#ifndef __EMSCRIPTEN__
    SDL_SetBooleanProperty(props, SDL_PROP_WINDOW_CREATE_HIGH_PIXEL_DENSITY_BOOLEAN, true);
#endif
#ifdef SDL_PLATFORM_ANDROID
    SDL_SetBooleanProperty(props, SDL_PROP_WINDOW_CREATE_FULLSCREEN_BOOLEAN, true);
#endif
    window = SDL_CreateWindowWithProperties(props);
    SDL_DestroyProperties(props);
    if (!window) {
        std::cout << "[sdl] window creation failed: " << SDL_GetError() << std::endl;
        return false;
    }

#ifdef __EMSCRIPTEN__
    SDL_SetWindowFillDocument(window, true);
#endif

    SDL_PropertiesID wp = SDL_GetWindowProperties(window);
    const char* driver = SDL_GetCurrentVideoDriver();
    std::string drv = driver ? driver : "";
#if defined(SDL_PLATFORM_EMSCRIPTEN)
    native.window = const_cast<char*>("#canvas");
#elif defined(SDL_PLATFORM_WIN32)
    native.window = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_WIN32_HWND_POINTER, nullptr);
#elif defined(SDL_PLATFORM_MACOS)
    native.window = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_COCOA_WINDOW_POINTER, nullptr);
#elif defined(SDL_PLATFORM_ANDROID)
    native.window = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_ANDROID_WINDOW_POINTER, nullptr);
    lastNativeWindow = native.window;
#else
    if (drv == "wayland") {
        native.wayland = true;
        native.display = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_WAYLAND_DISPLAY_POINTER, nullptr);
        native.window = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_WAYLAND_SURFACE_POINTER, nullptr);
    } else {
        native.display = SDL_GetPointerProperty(wp, SDL_PROP_WINDOW_X11_DISPLAY_POINTER, nullptr);
        native.window = reinterpret_cast<void*>(
            (uintptr_t)SDL_GetNumberProperty(wp, SDL_PROP_WINDOW_X11_WINDOW_NUMBER, 0));
    }
#endif
    if (!native.window) {
        std::cout << "[sdl] no native window handle for video driver '" << drv << "'" << std::endl;
        return false;
    }
    std::cout << "[sdl] video driver: " << drv << std::endl;

    int w = 0, h = 0;
    SDL_GetWindowSizeInPixels(window, &w, &h);
    framebufferWidth = w > 0 ? w : 1280;
    framebufferHeight = h > 0 ? h : 720;

#ifndef __EMSCRIPTEN__
    bgfx::renderFrame();
#endif

    game = std::make_unique<perlin::Perlin>(args);
    if (!game->Initialize(this))
        return false;
    if (touchMode)
        game->GetInput().SetCaptured(true);
#ifndef __EMSCRIPTEN__
    SDL_RaiseWindow(window);
    if (SDL_GetWindowFlags(window) & SDL_WINDOW_INPUT_FOCUS)
        SetCursorCaptured(true);
#endif
    return true;
}

void AppPlatform_SDL::SetCursorCaptured(bool captured) {
    if (touchMode) {
        if (game)
            game->GetInput().SetCaptured(true);
        return;
    }
    if (!window || captured == cursorCaptured)
        return;
    if (SDL_SetWindowRelativeMouseMode(window, captured)) {
        cursorCaptured = captured;
        if (game)
            game->GetInput().SetCaptured(captured);
    }
}

void AppPlatform_SDL::HandleEvent(const SDL_Event& e) {
    perlin::Input* input = game ? &game->GetInput() : nullptr;
    switch (e.type) {
    case SDL_EVENT_QUIT:
    case SDL_EVENT_WINDOW_CLOSE_REQUESTED:
        isRunning = false;
        break;
    case SDL_EVENT_DROP_FILE:
        if (e.drop.data)
            PushDropped(e.drop.data);
        break;
    case SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED:
        if (e.window.data1 > 0 && e.window.data2 > 0) {
            framebufferWidth = e.window.data1;
            framebufferHeight = e.window.data2;
        }
        break;
    case SDL_EVENT_WINDOW_FOCUS_LOST:
    case SDL_EVENT_WINDOW_MINIMIZED:
    case SDL_EVENT_WINDOW_HIDDEN:
        if (input && (input->pauseOnLostFocus || e.type != SDL_EVENT_WINDOW_FOCUS_LOST))
            input->ReleaseAll();
        SetCursorCaptured(false);
        break;
    case SDL_EVENT_SCREEN_KEYBOARD_HIDDEN:
        keyboardShown = false;
        break;
    case SDL_EVENT_GAMEPAD_ADDED:
        if (!gamepad && (gamepad = SDL_OpenGamepad(e.gdevice.which)) && input)
            input->SetPadConnected(true);
        break;
    case SDL_EVENT_GAMEPAD_REMOVED:
        if (gamepad && SDL_GetGamepadID(gamepad) == e.gdevice.which) {
            SDL_CloseGamepad(gamepad);
            gamepad = nullptr;
            if (input) {
                input->SetPadConnected(false);
                input->SetPadLook(0, 0);
                for (int c = 0; c < 64; c++)
                    if (padState[c]) {
                        padState[c] = false;
                        input->OnPadUp(c);
                    }
            }
        }
        break;
    case SDL_EVENT_GAMEPAD_BUTTON_DOWN:
    case SDL_EVENT_GAMEPAD_BUTTON_UP: {
        if (!input || !gamepad)
            break;
        const bool pressed = e.type == SDL_EVENT_GAMEPAD_BUTTON_DOWN;
        const int code = e.gbutton.button;
        if (code < 0 || code >= 15)
            break;
        if (input->TextMode() && !input->PadCapture()) {
            if (code == perlin::Pad::A) {
                if (pressed)
                    input->OnMouseDown(0);
                else
                    input->OnMouseUp(0);
            } else if ((code == perlin::Pad::B || code == perlin::Pad::Start) && pressed) {
                input->OnKeyDown(perlin::Key::Escape);
                input->OnKeyUp(perlin::Key::Escape);
            }
            break;
        }
        if (code == perlin::Pad::LeftShoulder && pressed)
            input->OnMouseWheel(1.0f);
        else if (code == perlin::Pad::RightShoulder && pressed)
            input->OnMouseWheel(-1.0f);
        if (padState[code] != pressed) {
            padState[code] = pressed;
            if (pressed)
                input->OnPadDown(code);
            else
                input->OnPadUp(code);
        }
        break;
    }
    case SDL_EVENT_KEY_DOWN:
        if (input) {
            const int k = KeyFromScancode(e.key.scancode);
            if (k && !e.key.repeat)
                input->OnKeyDown(k);
            else if (k && e.key.repeat && input->TextMode())
                input->OnKeyRepeat(k);
            if (k == 'V' && input->TextMode() && (e.key.mod & SDL_KMOD_CTRL)) {
                if (char* clip = SDL_GetClipboardText()) {
                    const char* p = clip;
                    while (*p) {
                        Uint32 cp = SDL_StepUTF8(&p, nullptr);
                        if (cp >= 32 && cp != 127)
                            input->OnChar(static_cast<int>(cp));
                    }
                    SDL_free(clip);
                }
            }
        }
        break;
    case SDL_EVENT_TEXT_INPUT:
        if (input && input->TextMode()) {
            const char* p = e.text.text;
            while (p && *p) {
                Uint32 cp = SDL_StepUTF8(&p, nullptr);
                if (cp == 0)
                    break;
                input->OnChar(static_cast<int>(cp));
            }
        }
        break;
    case SDL_EVENT_KEY_UP:
        if (input)
            if (int k = KeyFromScancode(e.key.scancode))
                input->OnKeyUp(k);
        break;
    case SDL_EVENT_MOUSE_MOTION:
        if (e.motion.which == SDL_TOUCH_MOUSEID)
            break;
        if (!touchMode && touch.Editing() && input) {
            if (editMouseDown) {
                const float d = SDL_GetWindowPixelDensity(window);
                touch.FingerMove(*input, 9999, e.motion.x * d, e.motion.y * d, e.motion.xrel * d, e.motion.yrel * d);
            }
            break;
        }
        if (touchMode) {
#ifdef SDL_PLATFORM_ANDROID
            break;
#else
            SetTouchMode(false);
#endif
        }
        if (input) {
            if (cursorCaptured)
                input->OnMouseDelta(e.motion.xrel, e.motion.yrel);
            input->OnMouseMove(e.motion.x * SDL_GetWindowPixelDensity(window), e.motion.y * SDL_GetWindowPixelDensity(window));
        }
        break;
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (e.button.which == SDL_TOUCH_MOUSEID)
            break;
        if (!touchMode && touch.Editing() && input) {
            const float d = SDL_GetWindowPixelDensity(window);
            touch.SetViewport(framebufferWidth, framebufferHeight);
            editMouseDown = true;
            touch.FingerDown(*input, 9999, e.button.x * d, e.button.y * d);
            break;
        }
        if (touchMode) {
#ifdef SDL_PLATFORM_ANDROID
            break;
#else
            SetTouchMode(false);
#endif
        }
        if (!cursorCaptured && !(input && input->TextMode())) {
            SetCursorCaptured(true);
            break;
        }
        if (input)
            if (int b = ButtonIndex(e.button.button); b >= 0)
                input->OnMouseDown(b);
        break;
    case SDL_EVENT_MOUSE_WHEEL:
        if (input)
            input->OnMouseWheel(e.wheel.y);
        break;
    case SDL_EVENT_FINGER_DOWN:
    case SDL_EVENT_FINGER_MOTION:
    case SDL_EVENT_FINGER_UP:
    case SDL_EVENT_FINGER_CANCELED:
        if (e.tfinger.touchID == SDL_MOUSE_TOUCHID || e.tfinger.touchID == SDL_PEN_TOUCHID)
            break;
        if (input && !touchMode && e.type == SDL_EVENT_FINGER_DOWN)
            SetTouchMode(true);
        if (input && touchMode) {
            touch.SetViewport(framebufferWidth, framebufferHeight);
            const float w = static_cast<float>(framebufferWidth), h = static_cast<float>(framebufferHeight);
            const int64_t id = static_cast<int64_t>(e.tfinger.fingerID);
            const float x = e.tfinger.x * w, y = e.tfinger.y * h;
            if (e.type == SDL_EVENT_FINGER_DOWN) {
                if (input->Keyboard())
                    keyboardPending = 4;
                touch.FingerDown(*input, id, x, y);
            }
            else if (e.type == SDL_EVENT_FINGER_MOTION)
                touch.FingerMove(*input, id, x, y, e.tfinger.dx * w, e.tfinger.dy * h);
            else if (e.type == SDL_EVENT_FINGER_UP)
                touch.FingerUp(*input, id, x, y);
            else
                touch.Cancel(*input);
        }
        break;
    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (editMouseDown && input) {
            const float d = SDL_GetWindowPixelDensity(window);
            editMouseDown = false;
            touch.FingerUp(*input, 9999, e.button.x * d, e.button.y * d);
            break;
        }
        if (input)
            if (int b = ButtonIndex(e.button.button); b >= 0)
                input->OnMouseUp(b);
        break;
    default:
        break;
    }
}

void AppPlatform_SDL::PumpGamepad() {
    if (!game)
        return;
    perlin::Input& in = game->GetInput();
    const auto now = std::chrono::steady_clock::now();
    const float dt = padLast.time_since_epoch().count() == 0 ? 0.0f : std::min(0.1f, std::chrono::duration<float>(now - padLast).count());
    padLast = now;
    if (!gamepad) {
        in.SetPadLook(0, 0);
        return;
    }
    const auto axis = [&](SDL_GamepadAxis a) { return static_cast<float>(SDL_GetGamepadAxis(gamepad, a)) / 32767.0f; };
    const float lx = axis(SDL_GAMEPAD_AXIS_LEFTX), ly = axis(SDL_GAMEPAD_AXIS_LEFTY);
    const float rx = axis(SDL_GAMEPAD_AXIS_RIGHTX), ry = axis(SDL_GAMEPAD_AXIS_RIGHTY);
    const float lt = axis(SDL_GAMEPAD_AXIS_LEFT_TRIGGER), rt = axis(SDL_GAMEPAD_AXIS_RIGHT_TRIGGER);
    const float dz = in.PadDeadzone();
    const auto shape = [&](float v) {
        const float m = std::fabs(v);
        return m <= dz ? 0.0f : std::copysign(std::min(1.0f, (m - dz) / (1.0f - dz)), v);
    };

    if (in.TextMode() && !in.PadCapture()) {
        for (int c = 0; c < 64; c++)
            if (padState[c]) {
                padState[c] = false;
                in.OnPadUp(c);
            }
        in.SetPadLook(0, 0);
        const float sx = shape(lx), sy = shape(ly);
        if (sx != 0.0f || sy != 0.0f) {
            float x = 0, y = 0;
            SDL_GetMouseState(&x, &y);
            const float speed = 700.0f * dt / std::max(1.0f, SDL_GetWindowPixelDensity(window));
            SDL_WarpMouseInWindow(window, x + sx * std::fabs(sx) * speed * 1.4f, y + sy * std::fabs(sy) * speed * 1.4f);
        }
        padScroll += -shape(ry) * dt * 9.0f;
        if (std::fabs(padScroll) >= 1.0f) {
            in.OnMouseWheel(std::trunc(padScroll));
            padScroll -= std::trunc(padScroll);
        }
        return;
    }

    in.SetPadLook(shape(rx), shape(ry));
    struct Virtual { int code; bool on; };
    const float hi = 0.5f;
    const Virtual virtuals[] = {
        {perlin::Pad::LeftTrigger, lt > 0.4f}, {perlin::Pad::RightTrigger, rt > 0.4f},
        {perlin::Pad::LeftStickUp, ly < -hi}, {perlin::Pad::LeftStickDown, ly > hi},
        {perlin::Pad::LeftStickLeft, lx < -hi}, {perlin::Pad::LeftStickRight, lx > hi},
        {perlin::Pad::RightStickUp, ry < -hi}, {perlin::Pad::RightStickDown, ry > hi},
        {perlin::Pad::RightStickLeft, rx < -hi}, {perlin::Pad::RightStickRight, rx > hi}};
    for (const Virtual& v : virtuals) {
        if (padState[v.code] == v.on)
            continue;
        padState[v.code] = v.on;
        if (v.on)
            in.OnPadDown(v.code);
        else
            in.OnPadUp(v.code);
    }
}

void AppPlatform_SDL::PumpFrame() {
    SDL_Event e;
    while (SDL_PollEvent(&e))
        HandleEvent(e);
    PumpGamepad();

#ifdef SDL_PLATFORM_ANDROID
    {
        void* nw = SDL_GetPointerProperty(SDL_GetWindowProperties(window), SDL_PROP_WINDOW_ANDROID_WINDOW_POINTER, nullptr);
        if (!nw) {
            surfaceLost = true;
        } else if (nw != lastNativeWindow || surfaceLost) {
            const bool resumed = lastNativeWindow != nullptr;
            lastNativeWindow = nw;
            if (resumed || surfaceLost) {
                perlin_bgfx_android_window = nw;
                surfaceChanged = true;
                std::cout << "[sdl] window surface replaced, rebuilding the swap chain" << std::endl;
            }
            surfaceLost = false;
        }
    }
#endif

    {
        std::lock_guard lock(titleMutex);
        if (titleDirty) {
            SDL_SetWindowTitle(window, pendingTitle.c_str());
            titleDirty = false;
        }
    }

    if (game && touchMode)
        touch.Update(game->GetInput());

    if (game) {
        perlin::Input& in = game->GetInput();
        const bool text = in.TextMode();
        if (text != textActive) {
            textActive = text;
            if (text) {
                recaptureAfterText = cursorCaptured;
                SetCursorCaptured(false);
                if (!touchMode)
                    SDL_StartTextInput(window);
            } else {
                if (!touchMode)
                    SDL_StopTextInput(window);
                if (recaptureAfterText)
                    SetCursorCaptured(true);
                recaptureAfterText = false;
            }
        }
        if (touchMode) {
            const bool keyboard = in.Keyboard();
            if (!keyboard) {
                keyboardPending = 0;
                if (keyboardShown) {
                    keyboardShown = false;
                    SDL_StopTextInput(window);
                }
            } else if (keyboardPending > 0 && --keyboardPending == 0) {
                keyboardShown = true;
                SDL_StartTextInput(window);
            }
        }
    }

    if (cursorCaptured && !(SDL_GetWindowFlags(window) & SDL_WINDOW_INPUT_FOCUS))
        SetCursorCaptured(false);
}

void AppPlatform_SDL::Run() {
    while (isRunning) {
        PumpFrame();
        bgfx::renderFrame(8);
    }
}

void AppPlatform_SDL::Shutdown() {
    if (game) {
        std::atomic<bool> done{false};
        std::thread stopper([&] {
            game->Shutdown();
            done = true;
        });
        while (!done)
            bgfx::renderFrame(8);
        stopper.join();
        bgfx::renderFrame();
        game.reset();
    }
    if (window) {
        SDL_DestroyWindow(window);
        window = nullptr;
    }
    SDL_Quit();
}
