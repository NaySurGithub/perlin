vec4 v_color0     : COLOR0    = vec4(1.0, 1.0, 1.0, 1.0);
vec2 v_texcoord0  : TEXCOORD0 = vec2(0.0, 0.0);
vec2 v_fog        : TEXCOORD1 = vec2(0.0, 0.0);
float v_layer     : TEXCOORD2 = 0.0;
float v_visibility : TEXCOORD3 = 1.0;
vec3 v_rel        : TEXCOORD4 = vec3(0.0, 0.0, 0.0);
vec2 v_light      : TEXCOORD5 = vec2(0.0, 0.0);
vec3 v_tint       : TEXCOORD6 = vec3(1.0, 1.0, 1.0);

vec3 a_position  : POSITION;
vec4 a_color0    : COLOR0;
vec2 a_texcoord0 : TEXCOORD0;
vec4 a_texcoord1 : TEXCOORD1;
